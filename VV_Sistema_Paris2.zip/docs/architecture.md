# Arquitetura do VV Sistema

## Estrutura Geral